# Bingr TV

Android TV / Google TV WebView wrapper for https://bingr.one/home.

## Build

1. Install Android Studio (current stable) and JDK 17.
2. Open this folder in Android Studio.
3. Let Gradle sync.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK will be under `app/build/outputs/apk/debug/app-debug.apk`.

The app is intended for devices that support Android TV / Google TV and a D-pad remote.

Note: The app only embeds the website. You are responsible for using the website and its content in accordance with applicable laws and the site's terms.
